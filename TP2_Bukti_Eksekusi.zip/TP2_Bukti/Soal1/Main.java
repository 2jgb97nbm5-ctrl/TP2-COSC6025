import java.util.Scanner;
public class Main {
    static final int MIN_BUKU = 5;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); LinkedList list = new LinkedList();
        list.push("BK101", "Struktur Data", "Michael Goodrich");
        list.push("BK102", "Introduction to Algorithms", "Thomas Cormen");
        list.push("BK103", "Algoritma dan Pemrograman", "Rinaldi Munir");
        list.push("BK104", "Java Programming", "Y. Daniel Liang");
        list.push("BK105", "Basis Data", "Abdul Kadir"); int pilih = 0;
        do {
            System.out.println("\n===== SISTEM DATA BUKU =====\n1. Tambah Buku\n2. Hapus Buku\n3. Cari Buku\n4. Lihat Semua Buku\n5. Keluar"); System.out.print("Pilih menu: ");
            try { pilih = Integer.parseInt(sc.nextLine().trim()); } catch (NumberFormatException e) { pilih = 0; }
            switch (pilih) {
                case 1:
                    System.out.print("Masukkan Kode Buku: "); String kode = sc.nextLine().trim();
                    if (kode.isEmpty() || kode.length() > 5) { System.out.println("Kode buku tidak valid! (1-5 karakter)"); break; }
                    if (list.sudahAda(kode)) { System.out.println("Kode buku sudah digunakan!"); break; }
                    System.out.print("Masukkan Judul: "); String judul = sc.nextLine().trim(); System.out.print("Masukkan Penulis: "); String penulis = sc.nextLine().trim();
                    list.push(kode, judul, penulis); System.out.println("Data berhasil ditambahkan!");
                    if (list.getSize() < MIN_BUKU) System.out.println("(Catatan: data baru " + list.getSize() + " buku, minimal " + MIN_BUKU + " buku)"); break;
                case 2: if (list.pop()) System.out.println("Buku terakhir berhasil dihapus!"); else System.out.println("Tidak ada data untuk dihapus."); break;
                case 3: System.out.print("Masukkan Kode Buku yang dicari: "); Node hasil = list.cari(sc.nextLine().trim());
                    if (hasil != null) System.out.println("Buku ditemukan!\nKode: " + hasil.kodeBuku + " | Judul: " + hasil.judul + " | Penulis: " + hasil.penulis); else System.out.println("Buku tidak ditemukan."); break;
                case 4: list.tampil(); break;
                case 5: System.out.println("Terima kasih!"); break;
                default: System.out.println("Menu tidak valid!");
            }
        } while (pilih != 5); sc.close();
    }
}
