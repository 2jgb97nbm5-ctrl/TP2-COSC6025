public class LinkedList {
    private Node head; private int size;
    public int getSize() { return size; }
    public void push(String kode, String judul, String penulis) {
        Node baru = new Node(kode, judul, penulis);
        if (head == null) head = baru;
        else { Node cur = head; while (cur.next != null) cur = cur.next; cur.next = baru; }
        size++;
    }
    public boolean pop() {
        if (head == null) return false;
        if (head.next == null) head = null;
        else { Node cur = head; while (cur.next.next != null) cur = cur.next; cur.next = null; }
        size--; return true;
    }
    public Node cari(String kode) {
        Node cur = head; while (cur != null) { if (cur.kodeBuku.equalsIgnoreCase(kode)) return cur; cur = cur.next; }
        return null;
    }
    public boolean sudahAda(String kode) { return cari(kode) != null; }
    public void tampil() {
        if (head == null) { System.out.println("Daftar buku masih kosong."); return; }
        System.out.println("Daftar Buku:"); Node cur = head;
        while (cur != null) { System.out.println("Kode: " + cur.kodeBuku + " | Judul: " + cur.judul + " | Penulis: " + cur.penulis); cur = cur.next; }
        System.out.println("Total Buku: " + size);
    }
}
