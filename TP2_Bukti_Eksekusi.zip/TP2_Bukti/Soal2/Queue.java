public class Queue {
    private Node front, rear; private int size;
    public boolean isEmpty() { return front == null; } public int getSize() { return size; }
    public void enqueue(String kode, String nama, double total) {
        Node baru = new Node(kode, nama, total); if (rear == null) front = rear = baru; else { rear.next = baru; rear = baru; } size++;
    }
    public Node dequeue() { if (front == null) return null; Node n = front; front = front.next; if (front == null) rear = null; n.next = null; size--; return n; }
    public boolean sudahAda(String kode) { for (Node c = front; c != null; c = c.next) if (c.kode.equalsIgnoreCase(kode)) return true; return false; }
    public void tampil() { if (isEmpty()) { System.out.println("Antrian kosong."); return; } System.out.println("Antrian saat ini:"); int i=1; for (Node c=front;c!=null;c=c.next) System.out.printf("%d. %s | %s | Rp%,.0f%n",i++,c.kode,c.nama,c.total); System.out.println("Jumlah dalam antrian: "+size); }
}
