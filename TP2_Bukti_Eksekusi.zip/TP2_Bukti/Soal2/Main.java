import java.util.Scanner;
public class Main {
    static final int MIN_PELANGGAN = 5;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in); Queue antrian=new Queue(); Stack riwayat=new Stack();
        antrian.enqueue("A001","Andi",125000); antrian.enqueue("A002","Budi",80000); antrian.enqueue("A003","Citra",45000); antrian.enqueue("A004","Dewi",210000); antrian.enqueue("A005","Eko",95000); int pilih=0;
        do {
            System.out.println("\n=== SISTEM KASIR TOKO ===\n1. Tambah Antrian\n2. Layani Pelanggan\n3. Tampilkan Antrian\n4. Lihat Riwayat Transaksi\n5. Keluar"); System.out.print("Pilih menu: ");
            try { pilih=Integer.parseInt(sc.nextLine().trim()); } catch(NumberFormatException e) { pilih=0; }
            switch(pilih) {
                case 1: System.out.print("Masukkan Nomor Antrian: "); String kode=sc.nextLine().trim(); if(kode.isEmpty()||antrian.sudahAda(kode)){System.out.println("Nomor antrian kosong/sudah ada!");break;}
                    System.out.print("Masukkan Nama Pelanggan: "); String nama=sc.nextLine().trim(); System.out.print("Masukkan Total Belanja: "); double total;
                    try { total=Double.parseDouble(sc.nextLine().trim()); } catch(NumberFormatException e){System.out.println("Total belanja harus berupa angka!");break;}
                    if(total<0){System.out.println("Total belanja tidak boleh negatif!");break;} antrian.enqueue(kode,nama,total); System.out.println("Data pelanggan ditambahkan ke antrian!"); if(antrian.getSize()<MIN_PELANGGAN)System.out.println("(Catatan: antrian baru "+antrian.getSize()+" pelanggan, minimal "+MIN_PELANGGAN+")"); break;
                case 2: Node n=antrian.dequeue(); if(n==null)System.out.println("Tidak ada pelanggan dalam antrian."); else {System.out.println("Melayani pelanggan "+n.kode+" ("+n.nama+")");riwayat.push(n.kode,n.nama,n.total);System.out.println("Transaksi disimpan ke riwayat.");} break;
                case 3: antrian.tampil(); break; case 4: riwayat.tampil(); break; case 5: System.out.println("Terima kasih!"); break; default: System.out.println("Menu tidak valid!");
            }
        } while(pilih!=5); sc.close();
    }
}
