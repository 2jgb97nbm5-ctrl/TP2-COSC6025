public class Stack {
    private Node top; private int size;
    public boolean isEmpty() { return top == null; }
    public void push(String kode, String nama, double total) { Node baru = new Node(kode,nama,total); baru.next=top; top=baru; size++; }
    public void tampil() { if (isEmpty()) { System.out.println("Belum ada riwayat transaksi."); return; } System.out.println("Riwayat Transaksi (terbaru -> lama):"); for(Node c=top;c!=null;c=c.next) System.out.printf("%s | %s | Rp%,.0f%n",c.kode,c.nama,c.total); System.out.println("Total transaksi: "+size); }
}
